<?php
// Main entry point for the application
require_once __DIR__ . '/app/Router.php';

// Initialize and dispatch the router
$router = new Router();
$router->dispatch();
?>
