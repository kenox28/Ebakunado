            </div>
        </main>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Common JS -->
    <script src="../../js/supabase_js/admin/common.js?v=1.0.3"></script>
</body>
</html>
