    </div> <!-- End dashboard-container -->
    
    <script src="../../js/supabase_js/superadmin/common.js?v=1.0.4"></script>
    <?php if (isset($page_js)): ?>
        <script src="../../js/supabase_js/superadmin/<?php echo $page_js; ?>"></script>
    <?php endif; ?>
</body>
</html>
