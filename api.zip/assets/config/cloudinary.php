<?php
// Cloudinary Configuration
// Replace these with your actual Cloudinary credentials
return [
    'cloud_name' => 'dvecrmrst',
    'api_key' => '361691866917544',
    'api_secret' => 'LW-KoNdpUsBeNEuyoPYx62MVarI',
    'secure' => true
];
?>
