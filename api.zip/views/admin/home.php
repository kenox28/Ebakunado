<?php
// Redirect to new dashboard
header("Location: dashboard.php");
exit();
?>
