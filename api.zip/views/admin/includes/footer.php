            </div>
        </main>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Common JS -->
    <script src="../../js/admin/common.js?v=1.0.1"></script>
</body>
</html>
